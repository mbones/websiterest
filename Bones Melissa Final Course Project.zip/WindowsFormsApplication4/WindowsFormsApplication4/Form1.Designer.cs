﻿namespace WindowsFormsApplication4
{
    partial class srchTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.patientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doctorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.salesRepresentativeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doctorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.salesRepresentativesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.technicalSupportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ptSrchLname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.PtSrchFname = new System.Windows.Forms.TextBox();
            this.ptSrchDob = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.selectDropDown = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.directorySearcher2 = new System.DirectoryServices.DirectorySearcher();
            this.directoryEntry1 = new System.DirectoryServices.DirectoryEntry();
            this.eventLog1 = new System.Diagnostics.EventLog();
            this.eventLog2 = new System.Diagnostics.EventLog();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.patientSearch = new System.Windows.Forms.Panel();
            this.testSearch = new System.Windows.Forms.Panel();
            this.TestCode = new System.Windows.Forms.Label();
            this.Test_Name = new System.Windows.Forms.Label();
            this.SrchTestCode = new System.Windows.Forms.TextBox();
            this.srchTestName = new System.Windows.Forms.TextBox();
            this.pnlDoctorSearch = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.tbxLName = new System.Windows.Forms.TextBox();
            this.tbxFName = new System.Windows.Forms.TextBox();
            this.tbxDrFacility = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.srchSalesRep = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.SrSrchLname = new System.Windows.Forms.TextBox();
            this.SrSrchFName = new System.Windows.Forms.TextBox();
            this.SrSrchRegion = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog2)).BeginInit();
            this.patientSearch.SuspendLayout();
            this.testSearch.SuspendLayout();
            this.pnlDoctorSearch.SuspendLayout();
            this.srchSalesRep.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fToolStripMenuItem,
            this.addToolStripMenuItem,
            this.testToolStripMenuItem,
            this.doctorsToolStripMenuItem,
            this.salesRepresentativesToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 22);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1173, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // fToolStripMenuItem
            // 
            this.fToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fToolStripMenuItem.Name = "fToolStripMenuItem";
            this.fToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fToolStripMenuItem.Text = "File";
            this.fToolStripMenuItem.Click += new System.EventHandler(this.fToolStripMenuItem_Click);
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.homeToolStripMenuItem.Text = "Home";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.patientToolStripMenuItem,
            this.doctorToolStripMenuItem,
            this.salesRepresentativeToolStripMenuItem});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.addToolStripMenuItem.Text = "Edit";
            // 
            // patientToolStripMenuItem
            // 
            this.patientToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem1,
            this.editToolStripMenuItem});
            this.patientToolStripMenuItem.Name = "patientToolStripMenuItem";
            this.patientToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.patientToolStripMenuItem.Text = "Patient";
            // 
            // addToolStripMenuItem1
            // 
            this.addToolStripMenuItem1.Name = "addToolStripMenuItem1";
            this.addToolStripMenuItem1.Size = new System.Drawing.Size(96, 22);
            this.addToolStripMenuItem1.Text = "Add";
            this.addToolStripMenuItem1.Click += new System.EventHandler(this.addToolStripMenuItem1_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // doctorToolStripMenuItem
            // 
            this.doctorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem2,
            this.editToolStripMenuItem1});
            this.doctorToolStripMenuItem.Name = "doctorToolStripMenuItem";
            this.doctorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.doctorToolStripMenuItem.Text = "Doctor";
            // 
            // addToolStripMenuItem2
            // 
            this.addToolStripMenuItem2.Name = "addToolStripMenuItem2";
            this.addToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.addToolStripMenuItem2.Text = "Add";
            this.addToolStripMenuItem2.Click += new System.EventHandler(this.addToolStripMenuItem2_Click);
            // 
            // editToolStripMenuItem1
            // 
            this.editToolStripMenuItem1.Name = "editToolStripMenuItem1";
            this.editToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.editToolStripMenuItem1.Text = "Edit";
            this.editToolStripMenuItem1.Click += new System.EventHandler(this.editToolStripMenuItem1_Click);
            // 
            // salesRepresentativeToolStripMenuItem
            // 
            this.salesRepresentativeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem4,
            this.editToolStripMenuItem3});
            this.salesRepresentativeToolStripMenuItem.Name = "salesRepresentativeToolStripMenuItem";
            this.salesRepresentativeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.salesRepresentativeToolStripMenuItem.Text = "Sales Representative";
            // 
            // addToolStripMenuItem4
            // 
            this.addToolStripMenuItem4.Name = "addToolStripMenuItem4";
            this.addToolStripMenuItem4.Size = new System.Drawing.Size(152, 22);
            this.addToolStripMenuItem4.Text = "Add";
            this.addToolStripMenuItem4.Click += new System.EventHandler(this.addToolStripMenuItem4_Click);
            // 
            // editToolStripMenuItem3
            // 
            this.editToolStripMenuItem3.Name = "editToolStripMenuItem3";
            this.editToolStripMenuItem3.Size = new System.Drawing.Size(152, 22);
            this.editToolStripMenuItem3.Text = "Edit";
            this.editToolStripMenuItem3.Click += new System.EventHandler(this.editToolStripMenuItem3_Click);
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem});
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.testToolStripMenuItem.Text = "Test";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.viewToolStripMenuItem.Text = "View";
            this.viewToolStripMenuItem.Click += new System.EventHandler(this.viewToolStripMenuItem_Click);
            // 
            // doctorsToolStripMenuItem
            // 
            this.doctorsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem1});
            this.doctorsToolStripMenuItem.Name = "doctorsToolStripMenuItem";
            this.doctorsToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.doctorsToolStripMenuItem.Text = "Doctors";
            // 
            // viewToolStripMenuItem1
            // 
            this.viewToolStripMenuItem1.Name = "viewToolStripMenuItem1";
            this.viewToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.viewToolStripMenuItem1.Text = "View";
            this.viewToolStripMenuItem1.Click += new System.EventHandler(this.viewToolStripMenuItem1_Click);
            // 
            // salesRepresentativesToolStripMenuItem
            // 
            this.salesRepresentativesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem2});
            this.salesRepresentativesToolStripMenuItem.Name = "salesRepresentativesToolStripMenuItem";
            this.salesRepresentativesToolStripMenuItem.Size = new System.Drawing.Size(130, 20);
            this.salesRepresentativesToolStripMenuItem.Text = "Sales Representatives";
            // 
            // viewToolStripMenuItem2
            // 
            this.viewToolStripMenuItem2.Name = "viewToolStripMenuItem2";
            this.viewToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.viewToolStripMenuItem2.Text = "View";
            this.viewToolStripMenuItem2.Click += new System.EventHandler(this.viewToolStripMenuItem2_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runReportsToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // runReportsToolStripMenuItem
            // 
            this.runReportsToolStripMenuItem.Name = "runReportsToolStripMenuItem";
            this.runReportsToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.runReportsToolStripMenuItem.Text = "Run Reports";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.technicalSupportToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // technicalSupportToolStripMenuItem
            // 
            this.technicalSupportToolStripMenuItem.Name = "technicalSupportToolStripMenuItem";
            this.technicalSupportToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.technicalSupportToolStripMenuItem.Text = "Technical Support";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(962, 58);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // ptSrchLname
            // 
            this.ptSrchLname.Location = new System.Drawing.Point(80, 16);
            this.ptSrchLname.Name = "ptSrchLname";
            this.ptSrchLname.Size = new System.Drawing.Size(100, 20);
            this.ptSrchLname.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Search";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // PtSrchFname
            // 
            this.PtSrchFname.Location = new System.Drawing.Point(80, 43);
            this.PtSrchFname.Name = "PtSrchFname";
            this.PtSrchFname.Size = new System.Drawing.Size(100, 20);
            this.PtSrchFname.TabIndex = 5;
            // 
            // ptSrchDob
            // 
            this.ptSrchDob.Location = new System.Drawing.Point(80, 69);
            this.ptSrchDob.Name = "ptSrchDob";
            this.ptSrchDob.Size = new System.Drawing.Size(100, 20);
            this.ptSrchDob.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Last Name";
            // 
            // selectDropDown
            // 
            this.selectDropDown.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.selectDropDown.AllowDrop = true;
            this.selectDropDown.FormattingEnabled = true;
            this.selectDropDown.Items.AddRange(new object[] {
            "Patient",
            "Sales Representative",
            "Doctor",
            "Test"});
            this.selectDropDown.Location = new System.Drawing.Point(82, 58);
            this.selectDropDown.Name = "selectDropDown";
            this.selectDropDown.Size = new System.Drawing.Size(121, 21);
            this.selectDropDown.TabIndex = 8;
            this.selectDropDown.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "First Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "DOB";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(285, 49);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(374, 400);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Genetic Lab Software";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // directorySearcher2
            // 
            this.directorySearcher2.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher2.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher2.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // eventLog1
            // 
            this.eventLog1.SynchronizingObject = this;
            // 
            // eventLog2
            // 
            this.eventLog2.SynchronizingObject = this;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Aqua;
            this.button1.Location = new System.Drawing.Point(20, 205);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Aqua;
            this.button2.Location = new System.Drawing.Point(131, 204);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 13;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // patientSearch
            // 
            this.patientSearch.Controls.Add(this.label3);
            this.patientSearch.Controls.Add(this.ptSrchLname);
            this.patientSearch.Controls.Add(this.PtSrchFname);
            this.patientSearch.Controls.Add(this.ptSrchDob);
            this.patientSearch.Controls.Add(this.label4);
            this.patientSearch.Controls.Add(this.label5);
            this.patientSearch.Location = new System.Drawing.Point(694, 330);
            this.patientSearch.Name = "patientSearch";
            this.patientSearch.Size = new System.Drawing.Size(200, 100);
            this.patientSearch.TabIndex = 14;
            this.patientSearch.Visible = false;
            // 
            // testSearch
            // 
            this.testSearch.Controls.Add(this.TestCode);
            this.testSearch.Controls.Add(this.Test_Name);
            this.testSearch.Controls.Add(this.SrchTestCode);
            this.testSearch.Controls.Add(this.srchTestName);
            this.testSearch.Location = new System.Drawing.Point(30, 83);
            this.testSearch.Name = "testSearch";
            this.testSearch.Size = new System.Drawing.Size(200, 100);
            this.testSearch.TabIndex = 15;
            this.testSearch.Visible = false;
            // 
            // TestCode
            // 
            this.TestCode.AutoSize = true;
            this.TestCode.Location = new System.Drawing.Point(12, 64);
            this.TestCode.Name = "TestCode";
            this.TestCode.Size = new System.Drawing.Size(59, 13);
            this.TestCode.TabIndex = 3;
            this.TestCode.Text = "Test Code:";
            // 
            // Test_Name
            // 
            this.Test_Name.AutoSize = true;
            this.Test_Name.Location = new System.Drawing.Point(9, 24);
            this.Test_Name.Name = "Test_Name";
            this.Test_Name.Size = new System.Drawing.Size(62, 13);
            this.Test_Name.TabIndex = 2;
            this.Test_Name.Text = "Test Name:";
            // 
            // SrchTestCode
            // 
            this.SrchTestCode.Location = new System.Drawing.Point(80, 58);
            this.SrchTestCode.Name = "SrchTestCode";
            this.SrchTestCode.Size = new System.Drawing.Size(100, 20);
            this.SrchTestCode.TabIndex = 1;
            // 
            // srchTestName
            // 
            this.srchTestName.Location = new System.Drawing.Point(80, 18);
            this.srchTestName.Name = "srchTestName";
            this.srchTestName.Size = new System.Drawing.Size(100, 20);
            this.srchTestName.TabIndex = 0;
            // 
            // pnlDoctorSearch
            // 
            this.pnlDoctorSearch.Controls.Add(this.label6);
            this.pnlDoctorSearch.Controls.Add(this.tbxLName);
            this.pnlDoctorSearch.Controls.Add(this.tbxFName);
            this.pnlDoctorSearch.Controls.Add(this.tbxDrFacility);
            this.pnlDoctorSearch.Controls.Add(this.label7);
            this.pnlDoctorSearch.Controls.Add(this.label8);
            this.pnlDoctorSearch.Location = new System.Drawing.Point(694, 83);
            this.pnlDoctorSearch.Name = "pnlDoctorSearch";
            this.pnlDoctorSearch.Size = new System.Drawing.Size(200, 100);
            this.pnlDoctorSearch.TabIndex = 16;
            this.pnlDoctorSearch.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Last Name";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // tbxLName
            // 
            this.tbxLName.Location = new System.Drawing.Point(83, 14);
            this.tbxLName.Name = "tbxLName";
            this.tbxLName.Size = new System.Drawing.Size(100, 20);
            this.tbxLName.TabIndex = 11;
            this.tbxLName.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // tbxFName
            // 
            this.tbxFName.Location = new System.Drawing.Point(83, 40);
            this.tbxFName.Name = "tbxFName";
            this.tbxFName.Size = new System.Drawing.Size(100, 20);
            this.tbxFName.TabIndex = 12;
            this.tbxFName.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // tbxDrFacility
            // 
            this.tbxDrFacility.Location = new System.Drawing.Point(83, 67);
            this.tbxDrFacility.Name = "tbxDrFacility";
            this.tbxDrFacility.Size = new System.Drawing.Size(100, 20);
            this.tbxDrFacility.TabIndex = 13;
            this.tbxDrFacility.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "First Name";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 67);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Faclity";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // srchSalesRep
            // 
            this.srchSalesRep.Controls.Add(this.label9);
            this.srchSalesRep.Controls.Add(this.SrSrchLname);
            this.srchSalesRep.Controls.Add(this.SrSrchFName);
            this.srchSalesRep.Controls.Add(this.SrSrchRegion);
            this.srchSalesRep.Controls.Add(this.label10);
            this.srchSalesRep.Controls.Add(this.label11);
            this.srchSalesRep.Location = new System.Drawing.Point(30, 285);
            this.srchSalesRep.Name = "srchSalesRep";
            this.srchSalesRep.Size = new System.Drawing.Size(200, 100);
            this.srchSalesRep.TabIndex = 18;
            this.srchSalesRep.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "Last Name";
            // 
            // SrSrchLname
            // 
            this.SrSrchLname.Location = new System.Drawing.Point(83, 14);
            this.SrSrchLname.Name = "SrSrchLname";
            this.SrSrchLname.Size = new System.Drawing.Size(100, 20);
            this.SrSrchLname.TabIndex = 23;
            // 
            // SrSrchFName
            // 
            this.SrSrchFName.Location = new System.Drawing.Point(83, 40);
            this.SrSrchFName.Name = "SrSrchFName";
            this.SrSrchFName.Size = new System.Drawing.Size(100, 20);
            this.SrSrchFName.TabIndex = 24;
            // 
            // SrSrchRegion
            // 
            this.SrSrchRegion.Location = new System.Drawing.Point(83, 67);
            this.SrSrchRegion.Name = "SrSrchRegion";
            this.SrSrchRegion.Size = new System.Drawing.Size(100, 20);
            this.SrSrchRegion.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 27;
            this.label10.Text = "First Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 67);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 28;
            this.label11.Text = "Region";
            // 
            // srchTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(1173, 444);
            this.Controls.Add(this.srchSalesRep);
            this.Controls.Add(this.patientSearch);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.selectDropDown);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pnlDoctorSearch);
            this.Controls.Add(this.testSearch);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "srchTest";
            this.Text = "Genetic Lab ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog2)).EndInit();
            this.patientSearch.ResumeLayout(false);
            this.patientSearch.PerformLayout();
            this.testSearch.ResumeLayout(false);
            this.testSearch.PerformLayout();
            this.pnlDoctorSearch.ResumeLayout(false);
            this.pnlDoctorSearch.PerformLayout();
            this.srchSalesRep.ResumeLayout(false);
            this.srchSalesRep.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doctorsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesRepresentativesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem patientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doctorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem salesRepresentativeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem runReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem technicalSupportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox ptSrchLname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox PtSrchFname;
        private System.Windows.Forms.TextBox ptSrchDob;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox selectDropDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.DirectoryServices.DirectorySearcher directorySearcher2;
        private System.DirectoryServices.DirectoryEntry directoryEntry1;
        private System.Diagnostics.EventLog eventLog1;
        private System.Diagnostics.EventLog eventLog2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel testSearch;
        private System.Windows.Forms.Label TestCode;
        private System.Windows.Forms.Label Test_Name;
        private System.Windows.Forms.TextBox SrchTestCode;
        private System.Windows.Forms.TextBox srchTestName;
        private System.Windows.Forms.Panel patientSearch;
        private System.Windows.Forms.Panel pnlDoctorSearch;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbxLName;
        private System.Windows.Forms.TextBox tbxFName;
        private System.Windows.Forms.TextBox tbxDrFacility;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel srchSalesRep;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox SrSrchLname;
        private System.Windows.Forms.TextBox SrSrchFName;
        private System.Windows.Forms.TextBox SrSrchRegion;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}

